import React, { useState, useEffect } from 'react';
import { Activity, TrendingUp, TrendingDown, Zap, Navigation, AlertTriangle, CheckCircle, Clock, Users, Leaf, BarChart3, MapPin, Radio } from 'lucide-react';
import StatCard from './components/StatCard';
import IntersectionCard from './components/IntersectionCard';
import PredictionCard from './components/PredictionCard';

const TrafficOptimizerApp = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [liveData, setLiveData] = useState({
    avgSpeed: 42,
    congestionLevel: 68,
    activeSensors: 1247,
    incidentCount: 3
  });
  const [trafficFlow, setTrafficFlow] = useState(65);

  useEffect(() => {
    const interval = setInterval(() => {
      setLiveData(prev => ({
        avgSpeed: Math.max(20, Math.min(60, prev.avgSpeed + (Math.random() - 0.5) * 3)),
        congestionLevel: Math.max(30, Math.min(90, prev.congestionLevel + (Math.random() - 0.5) * 5)),
        activeSensors: 1247 + Math.floor(Math.random() * 10),
        incidentCount: Math.max(0, Math.min(8, prev.incidentCount + (Math.random() > 0.7 ? 1 : -0.3)))
      }));
      setTrafficFlow(prev => Math.max(30, Math.min(95, prev + (Math.random() - 0.5) * 8)));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white shadow-2xl">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-white/20 backdrop-blur-lg rounded-xl p-3">
                <Navigation className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">Urban Traffic Optimizer</h1>
                <p className="text-indigo-100 text-sm">AI-Powered Smart City Traffic Management</p>
              </div>
            </div>
            <div className="flex items-center gap-2 bg-white/20 backdrop-blur-lg rounded-full px-4 py-2">
              <Radio className="w-4 h-4 animate-pulse" />
              <span className="text-sm font-semibold">LIVE</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-6">
          <div className="flex gap-1">
            {[
              { id: 'overview', label: 'Overview', icon: BarChart3 },
              { id: 'predictions', label: 'AI Predictions', icon: Zap },
              { id: 'intersections', label: 'Intersections', icon: MapPin },
              { id: 'incidents', label: 'Incidents', icon: AlertTriangle }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-6 py-4 font-semibold transition-all ${
                  activeTab === tab.id
                    ? 'text-indigo-600 border-b-2 border-indigo-600 bg-indigo-50'
                    : 'text-gray-600 hover:text-gray-800 hover:bg-gray-50'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <Activity className="w-6 h-6 text-indigo-600" />
                Real-Time Metrics
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard icon={TrendingUp} label="Average Speed" value={liveData.avgSpeed} unit=" km/h" trend={-12} color="from-blue-500 to-cyan-500" />
                <StatCard icon={Activity} label="Congestion Level" value={liveData.congestionLevel} unit="%" trend={8} color="from-red-500 to-orange-500" />
                <StatCard icon={Radio} label="Active Sensors" value={liveData.activeSensors} unit="" color="from-green-500 to-emerald-500" />
                <StatCard icon={AlertTriangle} label="Active Incidents" value={liveData.incidentCount.toFixed(0)} unit="" trend={-25} color="from-purple-500 to-pink-500" />
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-gray-100">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-800">City-Wide Traffic Flow</h3>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Clock className="w-4 h-4" />
                  Updated 2s ago
                </div>
              </div>
              <div className="space-y-4">
                {[
                  { zone: 'Downtown Core', flow: trafficFlow, color: 'indigo' },
                  { zone: 'Northern District', flow: trafficFlow - 15, color: 'blue' },
                  { zone: 'Eastern Highway', flow: trafficFlow + 10, color: 'purple' },
                  { zone: 'Western Suburbs', flow: trafficFlow - 25, color: 'green' },
                  { zone: 'Southern Industrial', flow: trafficFlow - 5, color: 'orange' }
                ].map((zone, idx) => (
                  <div key={idx}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-semibold text-gray-700">{zone.zone}</span>
                      <span className="text-sm font-bold text-gray-800">{zone.flow.toFixed(0)}% capacity</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                      <div
                        className={`h-3 rounded-full transition-all duration-500 ease-out bg-gradient-to-r from-${zone.color}-400 to-${zone.color}-600`}
                        style={{ width: `${Math.min(100, Math.max(0, zone.flow))}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-green-500 to-emerald-600 text-white rounded-xl p-6 shadow-lg">
                <Leaf className="w-10 h-10 mb-3 opacity-90" />
                <div className="text-3xl font-bold mb-1">-2,340 kg</div>
                <div className="text-green-100">CO₂ Saved Today</div>
              </div>
              <div className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white rounded-xl p-6 shadow-lg">
                <Clock className="w-10 h-10 mb-3 opacity-90" />
                <div className="text-3xl font-bold mb-1">18 min</div>
                <div className="text-blue-100">Avg Time Saved/Trip</div>
              </div>
              <div className="bg-gradient-to-br from-purple-500 to-pink-600 text-white rounded-xl p-6 shadow-lg">
                <Users className="w-10 h-10 mb-3 opacity-90" />
                <div className="text-3xl font-bold mb-1">847K</div>
                <div className="text-purple-100">Commuters Served</div>
              </div>
            </div>
          </div>
        )}

        {/* Predictions Tab */}
        {activeTab === 'predictions' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
                <Zap className="w-6 h-6 text-yellow-500" />
                AI-Powered Traffic Predictions
              </h2>
              <div className="bg-gradient-to-r from-purple-100 to-pink-100 px-4 py-2 rounded-full">
                <span className="text-sm font-semibold text-purple-800">Neural Network Active</span>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-gray-100">
              <h3 className="text-lg font-bold text-gray-800 mb-4">Next 2 Hours - Downtown Core</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <PredictionCard time="15 min" prediction="Moderate" confidence={94} />
                <PredictionCard time="30 min" prediction="Heavy" confidence={91} />
                <PredictionCard time="1 hour" prediction="Heavy" confidence={87} />
                <PredictionCard time="2 hours" prediction="Light" confidence={82} />
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-gray-100">
                <h3 className="text-lg font-bold text-gray-800 mb-4">ML Model Performance</h3>
                <div className="space-y-4">
                  {[
                    { label: 'Prediction Accuracy', value: 94.2, color: 'from-green-400 to-emerald-500' },
                    { label: 'Model Confidence', value: 91.8, color: 'from-blue-400 to-indigo-500' },
                    { label: 'Response Time', value: 97, color: 'from-purple-400 to-pink-500', display: '0.3s' }
                  ].map((metric, idx) => (
                    <div key={idx}>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-gray-600">{metric.label}</span>
                        <span className="text-sm font-bold text-gray-800">{metric.display || `${metric.value}%`}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className={`bg-gradient-to-r ${metric.color} h-2 rounded-full`} style={{ width: `${metric.value}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-xl p-6 shadow-lg">
                <h3 className="text-lg font-bold mb-4">AI Insights</h3>
                <div className="space-y-3">
                  <div className="flex items-start gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3">
                    <CheckCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <div className="text-sm">
                      <div className="font-semibold mb-1">Optimal Route Detected</div>
                      <div className="text-indigo-100">Highway 101 is 12 min faster than usual due to reduced traffic</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3">
                    <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <div className="text-sm">
                      <div className="font-semibold mb-1">Congestion Alert</div>
                      <div className="text-indigo-100">Predicted heavy traffic at Main St in 45 min - rerouting 340 vehicles</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3">
                    <Zap className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <div className="text-sm">
                      <div className="font-semibold mb-1">Signal Optimization</div>
                      <div className="text-indigo-100">Adjusted 23 intersections - reducing avg wait by 18 seconds</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Intersections Tab */}
        {activeTab === 'intersections' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
              <MapPin className="w-6 h-6 text-indigo-600" />
              Smart Intersection Management
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <IntersectionCard name="Main St & 5th Ave" status="optimal" waitTime={12} throughput={145} />
              <IntersectionCard name="Broadway & Park" status="moderate" waitTime={28} throughput={98} />
              <IntersectionCard name="Highway 101 Exit 3A" status="optimal" waitTime={8} throughput={210} />
              <IntersectionCard name="Central Ave & Oak" status="congested" waitTime={45} throughput={67} />
              <IntersectionCard name="Market St & 2nd" status="optimal" waitTime={15} throughput={132} />
              <IntersectionCard name="River Rd & Bridge" status="moderate" waitTime={22} throughput={115} />
            </div>

            <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-gray-100">
              <h3 className="text-lg font-bold text-gray-800 mb-4">AI Signal Optimization Active</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-4xl font-bold text-indigo-600 mb-2">23</div>
                  <div className="text-sm text-gray-600">Intersections Managed</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-green-600 mb-2">-18s</div>
                  <div className="text-sm text-gray-600">Avg Wait Reduction</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-purple-600 mb-2">+31%</div>
                  <div className="text-sm text-gray-600">Throughput Increase</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Incidents Tab */}
        {activeTab === 'incidents' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
              <AlertTriangle className="w-6 h-6 text-orange-500" />
              Active Incidents & Alerts
            </h2>
            <div className="space-y-4">
              {[
                { type: 'accident', location: 'Highway 101 Mile 23', severity: 'high', time: '5 min ago', affected: 340 },
                { type: 'roadwork', location: 'Main St Bridge', severity: 'medium', time: '2 hours ago', affected: 120 },
                { type: 'weather', location: 'Northern District', severity: 'low', time: '15 min ago', affected: 85 }
              ].map((incident, idx) => (
                <div key={idx} className={`bg-white rounded-xl p-6 shadow-lg border-l-4 ${
                  incident.severity === 'high' ? 'border-red-500' :
                  incident.severity === 'medium' ? 'border-yellow-500' : 'border-blue-500'
                }`}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <AlertTriangle className={`w-5 h-5 ${
                          incident.severity === 'high' ? 'text-red-500' :
                          incident.severity === 'medium' ? 'text-yellow-500' : 'text-blue-500'
                        }`} />
                        <span className="font-bold text-gray-800 capitalize">{incident.type}</span>
                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                          incident.severity === 'high' ? 'bg-red-100 text-red-700' :
                          incident.severity === 'medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-blue-100 text-blue-700'
                        }`}>
                          {incident.severity.toUpperCase()}
                        </span>
                      </div>
                      <div className="text-gray-700 mb-2">{incident.location}</div>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span className="flex items-center gap-1"><Clock className="w-4 h-4" />{incident.time}</span>
                        <span className="flex items-center gap-1"><Users className="w-4 h-4" />{incident.affected} vehicles affected</span>
                      </div>
                    </div>
                    <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 transition-colors">
                      Manage
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TrafficOptimizerApp;
